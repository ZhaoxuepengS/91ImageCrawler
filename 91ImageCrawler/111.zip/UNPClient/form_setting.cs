﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Configuration;

namespace UNPClient
{
    public partial class form_setting :Form
    {
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);  
        private MainForm MainForm = null;
        public form_setting(MainForm mainform)
        {
            InitializeComponent();
            this.MainForm = mainform;
        }

        private void form_setting_Load(object sender, EventArgs e)
        {
            // 
            // ipBox
            // 
            this.groupBox1.Controls.Add(IpBox1);
            this.IpBox1.Location = new System.Drawing.Point(78, 48);
            this.IpBox1.Name = "ipBox";
            // 
            // ipBox2
            //       
            this.groupBox2.Controls.Add(IpBox2);
            this.IpBox2.Location = new System.Drawing.Point(79, 54);
            this.IpBox2.Name = "ipBox2";
            ////radio按钮效果
            //if (radioButton1.Checked) {
            //    this.IpBox1.setEnabled(false);
            //}
            //else if (radioButton2.Checked) {
            //    this.IpBox1.setEnabled(true);
            //}

            //if (radioButton4.Checked)
            //{
            //    this.IpBox2.setEnabled(false);
            //}
            //else if (radioButton3.Checked)
            //{
            //    this.IpBox2.setEnabled(true);
            //}
            //加载配置
            if (("0".Equals(ConfigurationManager.AppSettings["isGetClientIP"])))
            {
                this.radioButton2.Checked = true;
                this.IpBox1.setEnabled(true);
                IpBox1.IpAddressString = ConfigurationManager.AppSettings["ClientIP"];
            }
            else {
                this.radioButton1.Checked = true;
                this.IpBox1.setEnabled(false);
            }
            if (("0".Equals(ConfigurationManager.AppSettings["isGetVmIP"])))
            {
                this.radioButton3.Checked = true;
                this.IpBox2.setEnabled(true);
                this.IpBox2.IpAddressString = ConfigurationManager.AppSettings["vmIpAddr"];
            }
            else {
                this.radioButton4.Checked = true;
                this.IpBox2.setEnabled(false);
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                this.IpBox1.setEnabled(true);
            }
            else {
                this.IpBox1.setEnabled(false);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                this.IpBox2.setEnabled(true);
            }
            else
            {
                this.IpBox2.setEnabled(false);
            }
        }
        
        private IpInputBox IpBox1 = new IpInputBox(false);
        private IpInputBox IpBox2 = new IpInputBox(false);

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                string VMIp = IpBox2.IpAddressString;
                MainForm.SaveConfig("0", "isGetVmIP");
                MainForm.SaveConfig(VMIp, "vmIpAddr");
            }
            else {
                MainForm.SaveConfig("1", "isGetVmIP");
            }

            if (radioButton2.Checked)
            {
                string clientIP = IpBox1.IpAddressString;
                string cmd = "netsh interface ip set address name=\"VPN\" static " + clientIP + " 255.255.255.0";
                MainForm.SaveConfig(clientIP, "ClientIP");
                MainForm.SaveConfig("0", "isGetClientIP");
                execCmd(cmd);                
            }
            else {
                string cmd = "netsh interface ip set address name=\"VPN\" source=dhcp";
                MainForm.SaveConfig("1", "isGetClientIP");
                execCmd(cmd);
            }
            this.Close();
        }

        private bool execCmd(string cmd) {
            try
            {
                Process p = new Process();
                p.StartInfo.FileName = "cmd.exe";

                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                //不显示程序窗口
                p.StartInfo.CreateNoWindow = true;
                p.Start();

                p.StandardInput.WriteLine(cmd + "&exit");
                p.WaitForExit();
                p.Close();
            }
            catch (Exception e) {
                log.Error("执行设置IP命令出错"+e.StackTrace);
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
