﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;

namespace UNPClient
{
    
    class SoftVPN
    {
        System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding(false);
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);  
        string createVPNBatPath = Common.createVPNBatPath;
        string getListTmpPath = Common.getListTmpPath;
        string disconnectVPNBatPath = Common.disconnectVPNBatPath;
        /* Method：获取所有当前VPN连接
         * Parma：
         * return：VPN连接集合 VpnConnections
         * author：zhaoxuepeng/z04326
         */
        public List<VpnConnection> getVpnList() {
            log.Info("获取UNP全部连接信息：");
            //执行bat脚本，导出所有VPN连接
            string getVpnListCmd = "vpncmd /CLIENT localhost /CMD:accountList >"+"\""+getListTmpPath+"\"";
            WriteCmdToBat(getVpnListCmd, Common.getListBatPath);
            excuteBatFile(Common.getListBatPath);
            File.Delete(Common.getListBatPath);
            List<VpnConnection> VpnConnections = new List<VpnConnection>();
            StreamReader sr = new StreamReader(getListTmpPath, Encoding.UTF8);
            String line;
            VpnConnection vpnConn = null ;
            bool boo = false; 
            while ((line = sr.ReadLine()) != null) {
                if(line.Contains("VPN 连接设置名称")){
                    vpnConn = new VpnConnection();
                    string VpnName = line.Substring(line.IndexOf("|")+1);
                    vpnConn.VpnConName = VpnName;
                    boo = true;
                }else if(line.Contains("VPN Server 主机名") && boo){
                    string VpnAddr = line.Substring(line.IndexOf("|") + 1, line.IndexOf(":") - line.IndexOf("|")-1);
                    string VpnPort = line.Substring(line.IndexOf(":") + 1, line.LastIndexOf("(") - 1 - line.IndexOf(":"));
                    vpnConn.VpnConAddr = VpnAddr;
                    vpnConn.VpnConPort = VpnPort;
                }
                else if (line.Contains("虚拟 HUB 名称") && boo) {
                    string VpnHub = line.Substring(line.IndexOf("|")+1);
                    vpnConn.VpnHub = VpnHub;
                    log.Info("添加UNP连接："+vpnConn.VpnConName);
                    VpnConnections.Add(vpnConn);
                    boo = false;
                }
            } 
            log.Info("共获取到"+VpnConnections.Count()+"个UNP连接");
            return VpnConnections;
        }

        /* Method：接收字符串并写入指定的bat文件
         * Parma：cmd：要写入的命令；filepath：bat文件路径
         * return：
         * author：zhaoxuepeng/z04326
         */
        private void WriteCmdToBat(string cmd,string filepath) {
            System.IO.File.WriteAllText(filepath,cmd,utf8);
        }

        /* Method：执行指定的bat文件
         * author：zhaoxuepeng/z04326
         */
        private void excuteBatFile(string batFilePath) {
            Process proc = null;
            proc = new Process();
            proc.StartInfo.FileName = batFilePath;
            proc.StartInfo.CreateNoWindow = true;
            proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            proc.Start();
            proc.WaitForExit();
            proc.Close();
        }

        /* Method：创建一个VPN连接
         * author：zhaoxuepeng/z04326
         */
        public void CreateVpnConn(VpnConnection VpnConn) {
            log.Info("开始创建VPN连接："+VpnConn.VpnConName);
            //编辑创建vpn.bat
            string createVPNCmd = "vpncmd /CLIENT localhost /CMD:accountcreate "+VpnConn.VpnConName+" /SERVER:"+VpnConn.VpnConAddr+":"
                + VpnConn.VpnConPort + " /HUB:" + VpnConn.VpnHub + " /USERNAME:" + VpnConn.VpnUsername + " /NICNAME:VPN\r\nvpncmd /CLIENT localhost /CMD:accountPasswordSet "
                + VpnConn.VpnConName +" /PASSWORD:" + VpnConn.VpnPassword + " /TYPE:standard\r\n"
                + "vpncmd /CLIENT localhost /CMD:accountretryset " + VpnConn.VpnConName + " /NUM:3 /INTERVAL:5\r\n"
                + "vpncmd /CLIENT localhost /CMD:accountstatushide " + VpnConn.VpnConName;
            WriteCmdToBat(createVPNCmd, createVPNBatPath);
            //执行bat脚本，创建VPN连接
            excuteBatFile(createVPNBatPath);
            File.Delete(createVPNBatPath);
        }

        /* Method：判断VPN连接是否存在
         * author：zhaoxuepeng/z04326
         */
        public bool ifVpnConnExist(string vpnName) {
            string getVpnListCmd = "/CLIENT localhost /CMD:accountList";
            string vpnList = execSoftVpnCmd(getVpnListCmd);
            if (vpnList.Contains("UNP_Connection")) {
                return true;
            }
            return false;
        }
 

         /* Method：更新VPN连接信息
         * author：zhaoxuepeng/z04326
         */
        public void updateVpnConn(VpnConnection VpnConn) {
            log.Info("开始更新VPN连接：" + VpnConn.VpnConName);
            string updateCmd = "accountdelete "+VpnConn.VpnConName+"\r\naccountcreate " + VpnConn.VpnConName + " /SERVER:" + VpnConn.VpnConAddr + ":"
            + VpnConn.VpnConPort + " /HUB:" + VpnConn.VpnHub + " /USERNAME:" + VpnConn.VpnUsername + " /NICNAME:VPN\r\naccountPasswordSet "
            + VpnConn.VpnConName + " /PASSWORD:" + VpnConn.VpnPassword + " /TYPE:standard\r\n"
            + "accountretryset " + VpnConn.VpnConName + " /NUM:3 /INTERVAL:5\r\n"
            + "accountstatushide " + VpnConn.VpnConName; ;
            System.IO.File.WriteAllText(Common.updateInPath, updateCmd, utf8);
            //编辑创建vpn.bat
            string cmd = "/CLIENT localhost /IN:\"" + Common.updateInPath +"\"";
            execSoftVpnCmd(cmd);
            //WriteCmdToBat(undateVPNCmd, createVPNBatPath);
            //执行bat脚本，更新VPN连接
            //excuteBatFile(createVPNBatPath);
            //File.Delete(createVPNBatPath);
        }

        /* Method：连接VPN服务器
         * author：zhaoxuepeng/z04326
         */
        public void ConnectVpnServer(VpnConnection VpnConn)
        {
            log.Info("开始连接VPN服务器：" + VpnConn.VpnConName+"IP:"+VpnConn.VpnConAddr);
            string ConnectVPNCmd = "/CLIENT localhost /CMD:accountconnect "+VpnConn.VpnConName;
            string ret = execSoftVpnCmd(ConnectVPNCmd);
            if (!ret.Contains("命令成功完成")) {
                log.Error("连接VPN命令出错：" + ret);
            }
            //WriteCmdToBat(ConnectVPNCmd, createVPNBatPath);
            ////执行bat脚本，连接VPN服务器
            //excuteBatFile(createVPNBatPath);
            //File.Delete(createVPNBatPath);
            return;
        }
       /* Method：生成VPN连接状态查询文件
       * author：zhaoxuepeng/z04326
       */
        public void createVpnConnectStatusBat(string VpnConnName)
        {
            string ConnectVPNCmd = "vpncmd /CLIENT localhost /CMD:accountstatusget " + VpnConnName + " >" + "\""+getListTmpPath+"\"";
            WriteCmdToBat(ConnectVPNCmd, Common.getSingleConnPath);
        }
        /* Method：查询VPN连接状态
        * author：zhaoxuepeng/z04326
        */
        public string getVpnConnStatus(string VpnConnName) {
            log.Info("查询VPN连接状态：" + VpnConnName);
            string ConnVpnCmd = "/CLIENT localhost /CMD:accountstatusget " + VpnConnName;
            string ConnStatus = execSoftVpnCmd(ConnVpnCmd);

            if (ConnStatus.Contains("开始连接 VPN 服务器"))
            {
                return "正在连接VPN服务器。。。";
            }
            else if (ConnStatus.Contains("重试"))
            {
                return "正在尝试重新连接。。。";
            }
            else if (ConnStatus.Contains("连接完成 (会话建立)"))
            {
                return "连接完成 (会话建立)";
            }
            else if (ConnStatus.Contains("错误代码: 37")) {
                return "连接失败，请检查目标地址是否正确。";
            }
            return "未获取到连接状态";
        }
        /* Method：断开指定VPN服务器
        * author：zhaoxuepeng/z04326
        */
        public void DisconnectVpnServer(VpnConnection VpnConn)
        {
            log.Info("断开连接VPN服务器：" + VpnConn.VpnConName + "IP:" + VpnConn.VpnConAddr);
            if (!File.Exists(createVPNBatPath)) {
                string ConnectVPNCmd = "vpncmd /CLIENT localhost /CMD:accountdisconnect " + VpnConn.VpnConName;
                WriteCmdToBat(ConnectVPNCmd, disconnectVPNBatPath);
            }
            //执行bat脚本，连接VPN服务器
            excuteBatFile(disconnectVPNBatPath);
            //File.Delete(createVPNBatPath);
            return;
        }
        
        public string execSoftVpnCmd(string cmd) {
            try
            {
                Process p = new Process();
                p.StartInfo.FileName = "vpncmd.exe";
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.CreateNoWindow = true;

                p.StartInfo.StandardOutputEncoding = Encoding.UTF8;
                p.StartInfo.Arguments = cmd;
                // 为异步获取订阅事件  
                //p.OutputDataReceived += new DataReceivedEventHandler(process_OutputDataReceived);
                //p.ErrorDataReceived += new DataReceivedEventHandler(p_ErrorDataReceived);
            
                p.Start();
                String output = p.StandardOutput.ReadToEnd();
                String err = p.StandardError.ReadToEnd();
                //p.BeginOutputReadLine();
                //p.BeginErrorReadLine();
                p.Close();
                if ("" != output)
                {
                    return output;
                }
                if ("" != err)
                {
                    return err;
                }
               
                return "";
            }
            catch (Exception e)
            {
                log.Error("执行vpncmd失败" + e.Message);
                return null;
            }    
        }
    }
}
