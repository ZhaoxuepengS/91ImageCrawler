﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UNPClient
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool create;
            using (Mutex mu = new Mutex(true, Application.ProductName, out create))
            {
                if (create)
                {
                    run();
                }
                else
                {
                    MessageBox.Show("程序已经运行!");
                }
            }
           
           
           
        }
        static void run() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }

    }
}
