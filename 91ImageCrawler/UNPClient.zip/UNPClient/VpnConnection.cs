﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UNPClient
{
    [Serializable]
    public class VpnConnection
    {
        public VpnConnection() { }

        public VpnConnection(string vpnConName, string vpnConAddr, string vpnConPort, string vpnHub, string vpnUsername, string vpnPassword)
        {
            this.VpnConName = vpnConName;
            this.vpnConAddr = vpnConAddr;
            this.vpnConPort = vpnConPort;
            this.vpnHub = vpnHub;
            this.vpnUsername = vpnUsername;
            this.vpnPassword = vpnPassword;
        }
        //Vpn连接各个属性
        private string vpnConName;
        private string vpnConAddr;
        private string vpnConPort;
        private string vpnHub;
        private string vpnUsername;
        private string vpnPassword;
        //VPN get set方法
        public string VpnConName
        {
            get { return vpnConName; }
            set { vpnConName=value;}
        }
        public string VpnConAddr
        {
            get { return vpnConAddr; }
            set { vpnConAddr = value; }
        }
        public string VpnConPort
        {
            get { return vpnConPort; }
            set { vpnConPort = value; }
        }
        public string VpnHub
        {
            get { return vpnHub; }
            set { vpnHub = value; }
        }
        public string VpnUsername
        {
            get { return vpnUsername; }
            set { vpnUsername = value; }
        }
        public string VpnPassword
        {
            get { return vpnPassword; }
            set { vpnPassword = value; }
        }
    }
}
