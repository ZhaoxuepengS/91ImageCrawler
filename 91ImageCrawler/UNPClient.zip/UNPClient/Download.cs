﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;

namespace UNPClient
{
    class Download
    {
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        /* Method：Http方式下载文件
         * Parma：<param name="url">http地址</param>
         * Parma：<param name="localfile">本地文件</param>
         * return：
         * author：zhaoxuepeng/z04326
         */
        public bool download(string url, string localfile)
        {
            bool flag = false;
            FileStream writeStream; // 写入本地文件流对象

            // 判断要下载的文件夹是否存在
            if (File.Exists(localfile))
            {
                File.Delete(localfile);
                writeStream = new FileStream(localfile, FileMode.Create);// 创建一个文件
            }
            else
            {
                writeStream = new FileStream(localfile, FileMode.Create);// 文件不保存创建一个文件
            }


            try
            {
                log.Info("开始下载路由文件"+url);
                HttpWebRequest myRequest = (HttpWebRequest)HttpWebRequest.Create(url);

                Stream readStream = myRequest.GetResponse().GetResponseStream();

                byte[] btArray = new byte[512];
                int contentSize = readStream.Read(btArray, 0, btArray.Length);

                while (contentSize > 0)
                {
                    writeStream.Write(btArray, 0, contentSize);
                    contentSize = readStream.Read(btArray, 0, btArray.Length);
                }

                //关闭流
                writeStream.Close();
                readStream.Close();

                flag = true;
            }
            catch (Exception)
            {
                writeStream.Close();
                flag = false;
            }

            return flag;
        }
    }
}
